# Sinoise

Sinoise is a deliberately small Android app for increasing signal-to-noise ratio.

## MVP

- Exactly 3 goals for today
- Persistent Not To Do list
- Silent goal notifications
- Reminder mode: recurring interval (1+ minute; Android may batch very short intervals) or chosen daily times
- Goal completion state appears in notifications
- Reminders restore after reboot/app update
- No account, analytics, ads, cloud backend, or subscription

## Build for free with GitHub Actions

1. Create a free **public** GitHub repository.
2. Upload the contents of this folder to the repository.
3. Open **Actions** and select **Build Sinoise APK**.
4. Choose **Run workflow**.
5. When it finishes, download the **Sinoise-debug-apk** artifact.
6. Unzip it and install `app-debug.apk` on your Android phone.

Public repositories using standard GitHub-hosted Actions runners are free according to GitHub's current billing docs.

## Android Studio

Open this folder as a Gradle project. It uses Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, and Android API 35.

## Notification behavior

The notification channel is created with low importance, no sound, no vibration, and no badge. Android may still apply device/OEM-specific notification behavior. Chosen-time reminders use battery-friendly inexact delivery rather than requesting exact-alarm privileges.
